/*#include <stdio.h>
int main() {
  int r1;
  printf("Dime la cantidad de asteriscos que quieres poner: ");
  scanf("%i",&r1);
  for(int i=0;i<r1;i++){
    for (int j=0;j<=i;j++){
      printf("*");
    }
    printf("\n");
  }

  char A[]="Manzana";
  int tamaño= sizeof(A)/sizeof(A[0]);
  printf("El numero de caracteres es: %d\n", tamaño); //Todos los caracteres contando el caracter nulo
  for(int i=0; i<tamaño; i++){
    printf("%c\n",A[i]);
  }
  char B[]= "Mango";
  for (int j=0;B[j]!='\0';j++){
    printf("%c\n", B[j]);
  }
  return 0;
}*/