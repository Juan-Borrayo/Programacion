/*#include <stdio.h>
//#include "stdio.h" //cuando hay "" quiere decir que la lubreria o el
// encabezado es creado por nosotros
int main() {
  printf("Juan Borrayo");
  return 0;
}
#define numero 5
#include <stdio.h>

int main(){
  printf("%d",numero);
  return 0;
}
#define numero(x) x*x
#include <stdio.h>
int main(){
  printf("%d",numero(5));
  return 0;
}*/