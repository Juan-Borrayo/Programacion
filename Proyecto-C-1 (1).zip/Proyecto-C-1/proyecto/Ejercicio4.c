/*#include <stdio.h>
int main(){
    float a, b, c;
    
    printf("Ingrese la longitud del primer lado: ");
    int r1=scanf("%f", &a);
    printf("Ingrese la longitud del segundo lado: ");
    int r2=scanf("%f", &b);
    printf("Ingrese la longitud del tercer lado: ");
    int r3=scanf("%f", &c);

    if ((a + b > c) && (a + c > b) && (b + c > a)) {
        if (a == b && b == c) {
            printf("El triángulo es equilátero.\n");
        } 
        else if (a == b || a == c || b == c) {
            printf("El triángulo es isósceles.\n");
        } 
        else {
            printf("El triángulo es escaleno.\n");
        }
    } 
    else {
        printf("Las longitudes ingresadas no forman un triángulo.\n");
    }

    return 0;
}*/
