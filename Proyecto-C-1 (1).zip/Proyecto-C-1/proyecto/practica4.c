/*#include <stdio.h>
#include <string.h>
int main() {
int opcion;
do {
    printf("\n----- MENU -----\n");
    printf("1. Calificaciones\n");
    printf("2. Calculadora\n");
    printf("3. Asteriscos\n");
    printf("4. Cadenas de texto\n");
    printf("5. Contraseña\n");
    printf("6. Bucle\n");
    printf("0. Salir\n");
    printf("Seleccione una opción: ");
    int r1=scanf("%d", &opcion);

    switch (opcion) {
        case 1:
            printf("Has seleccionado la Opción 1\n");
          int cali, suma=0, i;
          float promedio;
          for(i=0;i<4;i++){
            printf("Dame la calificacion: ");
            scanf("%i", &cali);
            suma += cali;
            promedio =suma/4;
          }
          printf("promedio:%.2f", promedio);
          if (promedio >= 90 ){
            printf("\nA");
          }
          else if (promedio >= 80){
            printf("\nB");
          }
          else if (promedio >= 70){
            printf("\nC");
          }
          else if (promedio >= 60){
            printf("\nD");
          }
          else{
            printf("\nE");
          }
            break;
        case 2:
            printf("Has seleccionado la Opción 2\n");
          int r10, eleccion;
          float r2, num1, r3, num2;
          printf("Operacion:\n 1.Suma\n 2.Resta\n 3.Multiplicacion\n 4.Division\n Seleccione el numero de la operacion que quiera: ");
          r10=scanf("%d", &eleccion);
          printf("Dame el primer numero: ");
          r2=scanf("%f",&num1);
          printf("Dame el segundo numero: ");
          r3=scanf("%f", &num2);
          if (eleccion==1){
            printf("El resultado es: %.2f", num1+num2);
          }
          else if (eleccion==2){
            printf("El resultado es: %.2f", num1-num2);
          }
          else if (eleccion==3){
            printf("El resultado es: %.2f", num1*num2);
          }
          else if (eleccion==4){
            printf("El resultado es: %.2f", num1/num2);
          }
          else {
            printf("El numero ingresado no esta dentro del menu");
              }
            break;
        case 3:
            printf("Has seleccionado la Opción 3\n");
          int n;
          printf("Cuantos renglones: ");
          scanf("%i", &n);
          for(int i=1;i<=n;i++){
            for(int j=1;j<=i;j++){
              printf("*");
            }
            printf("\n");
          }
          for (int i = n - 1; i >= 1; i--) {
                for (int j = 1; j <= i; j++) {
                    printf("*");
                }
                printf("\n");
            }
            break;
        case 4:
            printf("Has seleccionado la Opción 4\n");
          char cadena1[100], cadena2[100];
          printf("Ingresa la primera cadena: ");
          char r4=scanf("%s", cadena1 );
          printf("Ingresa la segunda cadena: ");
          char r5=scanf("%s", cadena2);
          if(strcmp(cadena1,cadena2)==0){
            printf("las cadenas son iguales\n");
          }
          else {
              printf("las cadenas no son iguales\n");
            }
            break;
        case 5:
            printf("Has seleccionado la Opción 5\n");
          int intentos=3;
            char contraseña[100];
            printf("Ingrese la contraseña: ");
            char r7=scanf("%s", contraseña);
            while (strcmp(contraseña, "hola") != 0 && (intentos !=0)){
            printf("La contraseña es incorrecta, vuelvelo a intentar\n");
            intentos--;
            printf("Te quedan %d intentos\n", intentos);
            printf("Ingrese la contraseña: ");
            char r7=scanf("%s", contraseña);
          }
          if (intentos==0){
          printf("Intenta de nuevo mas tarde\n");
          }
            
          else{
          printf("Contraseña correcta, bienvenido\n");
          }
          break;
        case 6:
            printf("Has seleccionado la Opción 6\n");
          int r;
          do{
            printf("Ingrese un numero mayor que 10: ");
            int r6=scanf("%d", &r);
          }
          while (r<=10);
          printf("El numero que ingresaste es %d, es mayor que 10. ", r);
          break;
        case 0:
            printf("Saliendo del programa...\n");
          break;
        default:
            printf("Opción no válida, intenta de nuevo.\n");
    }

} while (opcion != 0);

  printf("Inicia ejercicio 3\n");
  //Ejercicio 3
  int x;
  for(x=0;x<16;x+=5){
    printf("el valor es: %d\n", x);
  }

  printf("Inicia ejercicio 4\n");
  //Ejercicio 4
  for(int i=0;i>-101;i-=20){
    printf("el valor es: %d\n", i);
  }

  printf("Inicia ejercicio 5\n");
  //Ejercicio 5
  int y=0;
  while(y <= 16){
     printf("el valor es: %d\n", y);
    y += 5;
  }

  printf("Inicia ejercicio 6\n");
  //Ejercicio 6
  int a=0;
  while (a>-101){
    printf("el valor es: %d\n", a);
    a-=20;
  }

  printf("Inicia ejercicio 9\n");
  //Ejercicio 9 segunda manera
  char contra[100], contra2[100], contra3[100];
  printf("Ingresa la contra: ");
  fgets(contra, sizeof(contra), stdin);
  printf("Ingresa la contra otra vez: ");
  fgets(contra2, sizeof(contra2), stdin);

  if (strcmp(contra, contra2) != 0){
    printf("Ingresa la contra otra vez: ");
    fgets(contra3, sizeof(contra3), stdin);
    if (strcmp(contra3, contra) !=0){
      printf("Acceso invalido");
    }
    else{
      printf("Acceso valido");
    }
  }
  else {
      printf("Acceso valido");
  }

  return 0;
}
*/