/*#include <stdio.h>
int main() {
    int numero;
    printf("Ingrese un número entero: ");
    int r1=scanf("%d", &numero);

    if (numero % 7 == 0 && numero % 11 == 0) {
        printf("El número es múltiplo de 7 y 11.\n");
    } else if (numero % 7 == 0) {
        printf("El número es múltiplo de 7.\n");
    } else if (numero % 11 == 0) {
        printf("El número es múltiplo de 11.\n");
    } else {
        printf("El número no es múltiplo de 7 ni de 11.\n");
    }
    return 0;
}*/
