/*#include <stdio.h>
int main(){
  int a;
  printf("Ingresa un numero entero: \n");
  int r1=scanf("%i",&a);
  if(a%5==0 && a%3==0){
    printf("El numero es divisible entre 3 y 5");
  }
  else{
    printf("El numero no es divisible entre 3 y 5");
  }
  return 0;
}*/
  