/*#include <stdio.h>
int main(){
  int a;
  printf("Ingrese el puntaje del estudiante: \n");
  int r1=scanf("%i",&a);
  if(a>=90){
    printf("La calificacion es: A");
  }
  else if(a>=80 && a<90){
    printf("La calificacion es: B");
  }
  else if(a>=70 && a<80){
    printf("La calificacion es: C");
  }
  else if(a>=60 && a<70){
    printf("La calificacion es: D");
  }
  else if(a<60){
    printf("La calificacion es: F");
  }
  return 0;
}*/