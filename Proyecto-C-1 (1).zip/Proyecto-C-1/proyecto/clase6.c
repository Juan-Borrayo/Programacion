/*#include <stdio.h>
int main(){
  int a;
  printf("dame un numero ");
  int r1=scanf("%i",&a);
  if (a>0){
    printf("el numero es positivo\n");
  }
  else if(a<0){
    printf("el numero es negativo\n");
  }
  else
    printf("el numero es cero\n");

  
  return 0;*/
/*
#include <stdio.h>
int main(){
  int a;
  printf("dame un numero ");
  int r1=scanf("%i",&a);
  if (a>0){
    if((a%2)==0){
      printf("el numero es par positivo\n");
    }
    else{
      printf("el numero es impar positivo\n");
    }
  }
  if(a<0){
    if ((a%2)==0){
      printf("el numero es par negativo\n");
  }
    else{
      printf("el numero es impar negativo\n");
    }
  else
    printf("el numero es cero\n");
  return 0;
#include <stdio.h>
int main(){
  int a,b,c;
  printf("dame tres numeros separados por espacio ");
  int r1=scanf("%i %i %i",&a,&b,&c);
  if ((a>b)&&(a>c)){
    printf("a es el numero mas grande\n");
  }
  else if ((b>a)&&(b>c)){
    printf("b es el numero mas grande\n");
  }
  else{
    printf("c es el numero mas grande\n");
  }
  return 0;
}
#include <stdio.h>
#include <string.h>
int main(){
  char c[20];
  char r3=scanf("%s",&c);
  if(strcmp(c,"rojo")==0){
    printf("el color es rojo\n");
  }
  else if(strcmp(c,"verde")==0){
      printf("el color es verde\n");
  }
  else {
    printf("no se conoce el color\n");
  }
  return 0;
}*/


  
  
