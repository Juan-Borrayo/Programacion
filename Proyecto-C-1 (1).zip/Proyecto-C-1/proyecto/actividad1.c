/*#include <stdio.h>
int main() {
    int Numero, Numero1;  
    float Letra;          
    char L;               

    printf("Dame un numero: ");
    int R1 = scanf("%i", &Numero);
    printf("Dame otro numero: ");
    int R2 = scanf("%i", &Numero1);
  
    while (getchar() != '\n');
    printf("Dame una letra: ");
    int R4 = scanf("%c", &L);
    while (getchar() != '\n');
  
    printf("Dame un numero flotante: ");
    int R3 = scanf("%f", &Letra);
    printf("Los valores son: %i, %i, %c, %.2f\n", Numero, Numero1, L, Letra);

    return 0;
}*/
