/*#include<stdio.h>

int main(){
  int numero=0x0A; //entero
  printf("El numero en formato decimal es :%d\n",numero);
  printf("El numero en formato entero es :%i\n",numero);
  return 0;
}
#include <stdio.h>
int main() {
  float flotante = 2.5643;
  double doble = 5.789;
  printf("el valor flotante es: %10.2f\n", flotante);
  printf("el valor flotante en notacion cientifica es: %.2e\n", flotante);
  printf("el valor de double es: %f\n", doble);
  printf("elvalor de double con lf es: %lf\n", doble);
  return 0;
}

//para printf %d y %i es indistinto
//%d<-es decimal
//%i<-es entero
//\n<-salto de linea
//%.nf<-n es el numero de decimales que queremos
//%e y %E<-notacion cientifica
%lf<-double
%s<-string
% es para poner el simbolo% en printf
\" es para colocar comillas dobles en print.f
\t tabulador
//*/