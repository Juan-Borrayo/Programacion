/*#include <stdio.h>
int main(){
  int c=214748364;
  printf("%d",c);
  return 0;
}
//sin signo int: 4294967295
//con signo : -2147483648, 2147483647
// short 2bytes
//sin signo int: 65535
//con signo int: -32768, 32767*/