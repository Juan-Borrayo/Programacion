/*#include <stdio.h>
int main() {
  int numero = 40;
  printf("Valor es %i\n y su direccion es : %p\n", numero,&numero);//accedemos a los datos a traves de la variable
  int *p = numero; //creamos un apuntador
  printf("Valor es %i\n y su direccion es : %p\n", *p, p);
  int *p = numero;//modificamos la variable a traves del apuntador
  return 0;
}*/
/*#include<stdio.h>
int main(){
  int numero, numero1;//declalar variable
  float letra;
  char l;
  //numero=5;//inicializar variable
  printf("dame un numero: ");
  int r1=scanf("%i",&numero);
  printf("dame otro numero: ");
  int r2=scanf("%i",&numero1);
  printf("dame una letra:");
  int r4=scanf("%c",&l);
  printf("dame un numero flotante");
  int r3=scanf("%f",&letra);
  printf("los valores son: %i%i%f",numero, numero1, letra);
  return 0;
}*/
/*#include<stdio.h>
int main(){
  char nombre[5];
  char apellido[10];
  int r1=scanf("%5s %s", nombre, apellido);
  printf("%s %s", nombre, apellido);
  return 0;
}
#include<stdio.h>
int main(){
  int nombre[]={1,2,3,4};
  int *pointer=nombre;
  printf("valor: %i, direccion: %\np", nombre[0], nombre);
  printf("valor: %i, direccion: %p\n", *pointer, pointer);
  pointer++;
  
  return 0;
}*/
