/*#include <stdio.h>
int main() { 
int x = 320; 
int y = 0; 
int res1 = !(17 & 32) ? 45 & 87 : 'A' > 27; 
int res2 = 0 || 2740 % 8 ^ 35 ? 320 > 2 : y; 
int res3 = (y += 2 ^ 25 + -x++ ? 1 : 0); 
int res4 = sizeof(x) + 1 - sizeof(y) % 4 | 7 / 3 + --y; 
printf("Resultado 1: %d\n", res1);
printf("Resultado 2: %d\n", res2); 
printf("Resultado 3: %d (y = %d)\n", res3, y); printf("Resultado 4: %d\n", res4); 
return 0; 
}*/