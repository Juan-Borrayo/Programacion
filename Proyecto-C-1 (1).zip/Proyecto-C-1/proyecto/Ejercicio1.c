/*#include <stdio.h>
int main(){
  int a;
  printf("Ingrese su edad: \n");
  int r1=scanf("%i",&a);
  if(a>=18) {
    printf("Eres mayor de edad\n");
  }
  else
    printf("Eres menor de edad\n");
  return 0;
}*/