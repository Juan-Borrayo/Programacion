/*#include <stdio.h>
int main(){
  int opciones;
  printf("Dame opciones del 0 al 5: ");
  int r1=scanf("%d", &opciones);
  switch (opciones){
    case 0:
    printf("la opcion que elegiste es la 0\n");
    break;
    case 1:
    printf("la opcion que elegiste es la 1\n");
    break;
    case 2:
    printf("la opcion que elegiste es la 2\n");
    break;
    case 3:
    printf("la opcion que elegiste es la 3\n");
    break;
    case 4:
    printf("la opcion que elegiste es la 4\n");
    break;
    case 5:
    printf("la opcion que elegiste es la 5\n");
    break;
    default: 
    printf("la opcion es diferente un valor entre 0 y 5\n");
    break;
  }
return 0;
}

#include <stdio.h>
int main(){
  char opciones;
  printf("Dame opciones del 0 al 5: ");
  char r1 =scanf("%c", &opciones);
  switch (opciones){
    case 'A':
    case 'a':
    printf("la opcion que elegiste es la a\n");
    break;
    case 'E':
    case 'e':
    printf("la opcion que elegiste es la e\n");
    break;
    case 'I':
    case 'i':
    printf("la opcion que elegiste es la i\n");
    break;
    case 'O':
    case 'o':
    printf("la opcion que elegiste es la 0\n");
    break;
    case 'U':
    case 'u':
    printf("la opcion que elegiste es la u\n");
    break;
    default: 
    printf("la opcion no es una vocal\n");
    break;
  }
return 0;
}
*/