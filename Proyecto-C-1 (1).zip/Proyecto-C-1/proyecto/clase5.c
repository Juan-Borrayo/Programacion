/*#include<stdio.h>
int main(){
  short int a=15, b=7;
  printf("%d\n",a&b); //and bit a bit
  printf("%d\n", a|b); //or bit a bit
  printf("%d\n",a^b); //or bit a bit
  //operadores de comparacion
  printf("%d\n", a<b);
  printf("%d\n", a>b);
  printf("%d\n", a<=b);
  printf("%d\n", a>=b);
  printf("%d\n", a==b);
  printf("%d\n", a!=b);
  //operadores logicos
  printf("Aqui empiezan operadores logicos\n%d\n",a&&b); //and si ambos se cumplen son verdaderos(1)
  printf("%d\n",(a==3)&&(b==7));
  printf("%d\n",(a==3)||(b==7));// si una o ambas son verdadero, entonces el resultado es 1
  printf("%d\n",!(b==7));
  printf("Aqui empiezan operadores ternarios\nsi a==15 el resultado es: %d\n",a==15?8:4);
  printf("si a==2 el resultado es: %d\n",a==2?8:4);
  a=5;
  b=10;
  int resultado1=b*a+2;
  int resultado2=a==5?4:1;
  int resultado3= --b%a++<2?4:2;
  int resultado4= 7&3/2+4-sizeof(resultado1)+(b-2)%7;
  printf(" resultado1 %d\n resultado2 %d\n resultado3 %d\n resultado4 %d\n",resultado1, resultado2, resultado3, resultado4);
  return 0;
}*/