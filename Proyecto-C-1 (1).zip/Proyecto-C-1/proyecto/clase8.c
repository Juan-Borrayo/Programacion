/*#include <stdio.h>
int main(){
  int a=2, contador=1;
  while (a<10){
    printf("el valor de a en la iteracion %d es: %d\n",a-1, a);
  a++;
  }
  printf("Aqui empieza el segundo ejemplo\n");
  a=2, contador=1;
  while (a<10){
    printf("el valor de a en la iteracion %d es: %d\n",contador, a);
  contador++;
    a++;
  }
  int a=2, contador=1;
  while (a<10){
    
    if (a<5){
      printf("el valor de a en la iteracion %d es: %d\n",a-1, a);
      a++;
      printf("sigues reprobado, echale mas ganas\n");
      
    }
    else {
      printf("el valor de a en la iteracion %d es: %d\n",a-1, a);
      a++;
    }
      
    
  }
  

  for(int i=2;i<10;i++){
    printf("el valor de a en iteracion %d es: %d\n", i-1, i);
  }
  
  int contador=1;
  printf("aqui empieza el segundo ejemplo");
  for(float i=2;i<10;i+=.5){
    printf("el valor de a en iteracion %d es: %f\n", contador, i);
    contador++;
  }

  int a=2;
  while (a>2 && a<8){
    printf("el valor de a es: %d\n", a);
  a++;
  }
  printf("termino while\n ------ empieza do while\n");
  a=2;

  do{
    printf("el valor de a es: %d\n",a);
    a++;
    if(a==7){
      goto etiqueta1;
    }
  }
  while(a>2 && a<15);
  etiqueta 1
return 0;
}
*/